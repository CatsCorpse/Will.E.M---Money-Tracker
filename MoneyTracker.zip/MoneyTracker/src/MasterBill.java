import javax.swing.*;
import java.util.Scanner;
import java.io.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import javafx.scene.control.Label;
import javafx.scene.text.Text;
import javafx.scene.layout.FlowPane;


public class MasterBill {
    private final int MAX_ARRAY_SIZE = 100;
    private final String INPUT_FILENAME = "testBills.txt";

    // Data storage arrays - related info stored in parallel

    private String[] name;
    private double[] amount;
    private int[] date;
    private int[] month;
    private String[] type;
    private String[] priority;
    private String[] payPlace;
    private String[] credentials;
    private String[] notes;

    // Number of actual data elements stored in array
    private int numElems;

    // Reference for input file
    private File inputfile;

    public MasterBill() {
        // Load arrays from file
        try {
            String dataLine;
            Scanner inputFileScanner;
            File inputfile;
            inputfile = new File(INPUT_FILENAME);
            inputFileScanner = new Scanner(inputfile);

            name = new String[MAX_ARRAY_SIZE];
            amount = new double[MAX_ARRAY_SIZE];
            date = new int[MAX_ARRAY_SIZE];
            month = new int[MAX_ARRAY_SIZE];
            type = new String[MAX_ARRAY_SIZE];
            priority = new String[MAX_ARRAY_SIZE];
            payPlace = new String[MAX_ARRAY_SIZE];
            credentials = new String[MAX_ARRAY_SIZE];
            notes = new String[MAX_ARRAY_SIZE];

            // Loop through file.  Tokenize each line into correct array.
            int i = 0;
            while (inputFileScanner.hasNext()) {
                // Read one line and instantiate a tokenizer object
                // Read the entire line
                dataLine = inputFileScanner.nextLine();

                // Split the line based on commas
                String[] tokens = dataLine.split(",");

                // Tokenize line and save data
                name[i] = tokens[0].trim(); // Trim to remove leading/trailing spaces
                amount[i] = Double.parseDouble(tokens[1].trim());
                date[i] = Integer.parseInt(tokens[2].trim());
                month[i] = Integer.parseInt(tokens[3].trim());
                type[i] = tokens[4].trim();
                priority[i] = tokens[5].trim();
                payPlace[i] = tokens[6].trim();
                credentials[i] = tokens[7].trim();
                notes[i] = tokens[8].trim();

                System.out.println("Name: " + name[i] + ", Amount: " + amount[i] + ", Date: " + date[i] +
                        ", Month: " + month[i] + ", Type: " + type[i] + ", Priority: " + priority[i] +
                        ", Pay Place: " + payPlace[i] + ", Credentials: " + credentials[i] + ", Notes: " + notes[i]);

                // Advance index
                i++;
            }
            numElems = i;

            inputFileScanner.close();   // Close file
        } catch (IOException e)  // If file error, send note to log and shut down.
        {
            System.out.println("File Input Error");
            System.exit(0);
        }
    }

    // This method returns one set of player data with formatting
    public String getBillFormatted(int index) {
        String boldText = name[index] + " = $"  + String.format("%.2f", amount[index]) + " (" + type[index] + ")" + "\n" +
                "Date/Month: " + date[index] + "/" + month[index] + "\n" +
                "Priority: " + priority[index] + "\n" +
                "Pay Place: " + payPlace[index] + "\n" + "Credentials: " + credentials[index] + "\n" +
                "Notes: " + notes[index] + "\n";

        return boldText;
    }





    // This method returns all data elements for a player as a multi-line string formatted for output.
    public String toString() {
        StringBuilder outString = new StringBuilder();

        // Iterate through all bill data
        for (int i = 0; i < numElems; i++) {
            // Append the formatted data to the StringBuilder
            outString.append(getBillFormatted(i)).append("\n");
        }

        return outString.toString();
    }


    public int getNumElems()
    {
        return numElems;
    }

    public double getTotalTotal()
    {
        double totalTotal = 0.0;

        // Iterate through all bill data
        for (int i = 0; i < numElems; i++) {

            totalTotal += amount[i];
        }

        return totalTotal;
    }

}