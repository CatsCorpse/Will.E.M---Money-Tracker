import java.util.ArrayList;
import java.util.List;

class BillManager {
    private List<Bill> bills;

    public BillManager() {
        this.bills = new ArrayList<>();
    }

    public void addBill(Bill bill) {
        bills.add(bill);
    }

    // Implement other methods for managing bills
}