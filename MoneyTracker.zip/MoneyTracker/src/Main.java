import javafx.application.Application;
import javafx.application.Platform;
import javafx.embed.swing.SwingNode;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;




////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public class Main extends Application {

    Bill bill = new Bill();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void main(String[] args) {
        launch(args);
    }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void start(Stage primaryStage) {
        // Show loading screen
        showLoadingScreen(primaryStage);

        // Initialize managers asynchronously
        new Thread(() -> {
            try {
                // Simulate loading time
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Switch to main menu
            Platform.runLater(() -> showMainMenu(primaryStage));
        }).start();
    }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private void showLoadingScreen(Stage primaryStage) {
        // Creating a rectangle to represent the loading icon
        Rectangle rectangle = new Rectangle(100, 100);
        rectangle.setStyle("-fx-fill: black; -fx-stroke: pink; -fx-stroke-width: 5px;");

        // Creating a RotateTransition for the loading animation
        RotateTransition rotateTransition = new RotateTransition(Duration.seconds(1), rectangle);
        rotateTransition.setByAngle(360);
        rotateTransition.setCycleCount(Animation.INDEFINITE);
        rotateTransition.setInterpolator(Interpolator.LINEAR);
        rotateTransition.play();

        Label initializingLabel = new Label("\n\n\n\nWaking up Will.E.M ...");
        initializingLabel.setStyle("-fx-font-size: 50pt; -fx-text-fill: white; -fx-font-family: \"Courier New\";");

        VBox initializingLabelBox = new VBox(initializingLabel);
        initializingLabelBox.setAlignment(Pos.TOP_CENTER);

        // Adding the rectangle to a StackPane
        StackPane root = new StackPane(initializingLabelBox, rectangle);
        root.setPrefSize(1500, 1500);
        root.setStyle("-fx-background-color: teal;");

        // Creating the Scene
        Scene scene = new Scene(root);


        // Setting the Scene to the Stage
        primaryStage.setScene(scene);
        primaryStage.setTitle("Initializing...");
        primaryStage.setX(0); // X coordinate - Set the location of the window
        primaryStage.setY(0); // Y coordinate - Set the location of the window
        primaryStage.show();
    }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private void showMainMenu(Stage primaryStage) {

        // Order of .txt file
        //NAME, AMOUNT, DATE, MONTH, TYPE, PRIORITY, PAYPLACE, CREDENTIALS, NOTES
        for (int i = 0; i < 100; i++)
        {
            bill.getBillFormattedByIndex(i);
        }



//.....................................................................................................................
    // TOP-DOWN LAYOUT OF MAIN MENU GUI
//=====================================================================================================================
        //
        //
        //
    //==================================================================================================================
        // GUI FOR MAIN MENU MENUBAR    ################################################################################
        //<editor-fold desc=">>>FOLD OF (GUI FOR MAIN MENU MENUBAR)">
        // Create menu bar
        MenuBar menuBar = new MenuBar();
        //..........................................................
        // Create menu tabs
        Menu fileMenu = new Menu("File");
        Menu editMenu = new Menu("Edit");
        Menu helpMenu = new Menu("Help");
        Menu heartMenu = new Menu("<3");
        //..........................................................
        // Create fileMenu items
        MenuItem newMenuItem = new MenuItem("New");
        MenuItem openMenuItem = new MenuItem("Open");
        MenuItem saveMenuItem = new MenuItem("Save");
        MenuItem exitMenuItem = new MenuItem("Exit");
        //..........................................................
        // Add menu items to File menu
        fileMenu.getItems().addAll(newMenuItem, openMenuItem, saveMenuItem,
                new SeparatorMenuItem(), exitMenuItem);
        //..........................................................
        // Create heartMenu items
        MenuItem oneHeartItem = new MenuItem("I");
        MenuItem twoHeartItem = new MenuItem("Love");
        MenuItem threeHeartItem = new MenuItem("You");
        MenuItem fourHeartItem = new MenuItem("Gariggle <3");
        //..........................................................
        // Add menu items to heartMenu
        heartMenu.getItems().addAll(oneHeartItem, twoHeartItem, threeHeartItem, fourHeartItem);
        //..........................................................
        // Apply CSS style to the MenuBar
        menuBar.setStyle("-fx-text-fill: white;");
        //..........................................................
        // Add menus to menu bar
        menuBar.getMenus().addAll(fileMenu, editMenu, helpMenu, heartMenu);
        //</editor-fold>
//=====================================================================================================================
    // GUI FOR WELCOME LABEL AND LEARN ABOUT ME BUTTON  ###############################################################
        //<editor-fold desc=">>>FOLD OF (GUI FOR WELCOME LABEL AND LEARN ABOUT ME BUTTON)">
        // Welcome label
        Label welcomeLabel = new Label("Welcome, I am Will.E.M!");

        // Learn about me button
        Button learnAboutMeButton = new Button("Learn about me!");
        learnAboutMeButton.setStyle("-fx-font-size: 10pt; -fx-border-width: 1 1 1 1 ;");

        // Associate button to listener
        learnAboutMeButton.setOnAction(e -> showLearnAboutMeDialog());

        //Welcome message and label box
        HBox welcomeLearnBox = new HBox(10);
        welcomeLearnBox.setStyle("-fx-border-color: black; -fx-border-width: 2px;"); // Set border style
        welcomeLearnBox.setPadding(new Insets(10)); // Add a larger padding to the VBox
        welcomeLearnBox.getChildren().addAll(welcomeLabel, learnAboutMeButton);
        welcomeLearnBox.setAlignment(Pos.TOP_CENTER);
        //</editor-fold>
//=====================================================================================================================
    // GUI FOR MONTHLY SECTIONS #######################################################################################
        //<editor-fold desc=">>>FOLD OF (GUI FOR MONTHLY SECTIONS)">
        // LAST MONTH - LABEL - SCROLLABLE TEXT AREA - TOTALS

        // Total Variables
        double lastMonthTotalDouble = 0.0;
        double lastMonthCurrentDouble = 0.0;

        // Last Month label
        Label lastMonthLabel = new Label("Last Month");

        // TextArea to display bills
        TextArea textAreaLastMonth = new TextArea();
        textAreaLastMonth.setPrefSize(600, 600); // Set preferred width and height
        textAreaLastMonth.setEditable(false); // Make it read-only
        textAreaLastMonth.setStyle("-fx-font-weight: bold;"); // Set the entire text bold
        textAreaLastMonth.setWrapText(true); // Enable text wrapping

        // Makes the TextArea scrollable
        ScrollPane scrollPaneLastMonth = new ScrollPane();
        scrollPaneLastMonth.setContent(textAreaLastMonth);
        scrollPaneLastMonth.setFitToWidth(true);
        scrollPaneLastMonth.setFitToHeight(true);

        //Totals labels
        Label lastMonthTotalTotalLabel = new Label("Total Total: $" + String.format("%.2f", lastMonthTotalDouble));
        Label lastMonthCurrentTotalLabel = new Label("Left to Pay: $" + String.format("%.2f", lastMonthCurrentDouble));

        // Last month bill label - Centered
        VBox lastMonthLabelBox = new VBox(1);
        lastMonthLabelBox.getChildren().addAll(lastMonthLabel,
                lastMonthTotalTotalLabel, lastMonthCurrentTotalLabel);
        lastMonthLabelBox.setAlignment(Pos.CENTER);

        // Last month contents box
        VBox lastMonthBox = new VBox(10);
        lastMonthBox.getChildren().addAll(lastMonthLabelBox, scrollPaneLastMonth);
        //..........................................................
        //
        //
        //
        // THIS MONTH - LABEL - SCROLLABLE TEXT AREA - TOTALS

        // Total Variables
        double thisMonthTotalDouble = bill.getTotalTotal();
        double thisMonthCurrentDouble = thisMonthTotalDouble;

        // This Month label
        Label thisMonthLabel = new Label("This Month");


// TextArea to display bills for this month
        TextArea textAreaThisMonth = new TextArea();
        textAreaThisMonth.setPrefSize(600, 600); // Set preferred width and height
        textAreaThisMonth.setEditable(false); // Make it read-only
        textAreaThisMonth.setWrapText(true); // Enable text wrapping

// Makes the TextArea scrollable
        ScrollPane scrollPaneThisMonth = new ScrollPane();
        scrollPaneThisMonth.setContent(textAreaThisMonth);
        scrollPaneThisMonth.setFitToWidth(true);
        scrollPaneThisMonth.setFitToHeight(true);

// Populate text area with bill data for this month
        for (int i = 0; i < bill.getNumElems(); i++) {
            textAreaThisMonth.appendText(bill.getBillFormattedByIndex(i) + "\n");
        }


//Totals labels
        Label thisMonthTotalTotalLabel = new Label("Total Total: $" + String.format("%.2f", thisMonthTotalDouble));
        Label thisMonthCurrentTotalLabel = new Label("Left to Pay: $" + String.format("%.2f", thisMonthCurrentDouble));

// This month bill label - Centered
        VBox thisMonthLabelBox = new VBox(1);
        thisMonthLabelBox.getChildren().addAll(thisMonthLabel,
                thisMonthTotalTotalLabel, thisMonthCurrentTotalLabel);
        thisMonthLabelBox.setAlignment(Pos.CENTER);

// This month contents box
        VBox thisMonthBox = new VBox(10);
        thisMonthBox.getChildren().addAll(thisMonthLabelBox, scrollPaneThisMonth);

        //..........................................................
        //
        //
        //
        // NEXT MONTH - LABEL - SCROLLABLE TEXT AREA - TOTALS

        // Total Variables
        double nextMonthTotalDouble = 0.0;
        double nextMonthCurrentDouble = 0.0;

        // Next Month label
        Label nextMonthLabel = new Label("Next Month");

        // TextArea to display bills
        TextArea textAreaNextMonth = new TextArea();
        textAreaNextMonth.setPrefSize(600, 600); // Set preferred width and height
        textAreaNextMonth.setEditable(false); // Make it read-only
        textAreaNextMonth.setStyle("-fx-font-weight: bold;"); // Set the entire text bold
        textAreaNextMonth.setWrapText(true); // Enable text wrapping

        // Makes the TextArea scrollable
        ScrollPane scrollPaneNextMonth = new ScrollPane();
        scrollPaneNextMonth.setContent(textAreaNextMonth);
        scrollPaneNextMonth.setFitToWidth(true);
        scrollPaneNextMonth.setFitToHeight(true);

        //Totals labels
        Label nextMonthTotalTotalLabel = new Label("Total Total: $" + String.format("%.2f", nextMonthTotalDouble));
        Label nextMonthCurrentTotalLabel = new Label("Left to Pay: $" + String.format("%.2f", nextMonthCurrentDouble));

        // Next month bill label - Centered
        VBox nextMonthLabelBox = new VBox(1);
        nextMonthLabelBox.getChildren().addAll(nextMonthLabel,
                nextMonthTotalTotalLabel, nextMonthCurrentTotalLabel);
        nextMonthLabelBox.setAlignment(Pos.CENTER);

        // Next month contents box
        VBox nextMonthBox = new VBox(10);
        nextMonthBox.getChildren().addAll(nextMonthLabelBox, scrollPaneNextMonth);
        //..........................................................
        //
        //
        //
        // HBOX OF MONTH BOXES
        HBox textAreaMonthBoxes = new HBox(10);
        textAreaMonthBoxes.setStyle("-fx-border-color: black; -fx-border-width: 2px;"); // Set border style
        textAreaMonthBoxes.setPadding(new Insets(10)); // Add a larger padding to the VBox
        textAreaMonthBoxes.getChildren().addAll(lastMonthBox, thisMonthBox, nextMonthBox);
        textAreaMonthBoxes.setAlignment(Pos.CENTER);
        //----------------------------------------------------------------
        //</editor-fold>
//=====================================================================================================================
    // GUI FOR ADDING A BILL ###########################################################################################
        //<editor-fold desc=">>>FOLD OF(GUI FOR ADDING A BILL)">
        // Add Bill Submit Button
        Button submitAddBill = new Button("Submit");

        // Associate button to listener/ Confirm Adding bill
        submitAddBill.setOnAction(e -> {
            if (showConfirmationDialog("Are you sure you want to add this bill?")) {
                addBillToList();
            }
        });
        // Add Expense label
        Label labelAddBill = new Label("Add Expense");

        // HBox of Submit Button and Add Expense label
        HBox labelAddBillBox = new HBox(10);
        labelAddBillBox.getChildren().addAll(labelAddBill, submitAddBill);
        //..........................................................
        //
        //
        //
        // Add Bill Name

        // LABEL
        Label billNameAddBill = new Label("Bill Name: ");

        // TEXTFIELD
        String addBillNameTextAreaDefault = "Type a descriptive name here";
        TextField billNameAddBillTextArea = new TextField();
        billNameAddBillTextArea.setPrefWidth(220); // Set preferred width
        billNameAddBillTextArea.setPrefHeight(20); // Set preferred height
        billNameAddBillTextArea.setStyle("-fx-prompt-text-fill: #000000;"); // Set prompt text color to darker shade of gray
        billNameAddBillTextArea.setPromptText(addBillNameTextAreaDefault);

        // HBOX
        HBox billNameAddBillBox = new HBox(10);
        billNameAddBillBox.getChildren().addAll(billNameAddBill, billNameAddBillTextArea);
        //..........................................................
        //
        //
        //
        // Add Bill Amount

        // LABEL
        Label amountAddBill = new Label("Amount: $");

        // TEXTFIELD
        String addBillAmountTextAreaDefault = "Type numbers and decimals";
        TextField amountAddBillTextArea = new TextField();
        amountAddBillTextArea.setPrefWidth(230); // Set preferred width
        amountAddBillTextArea.setPrefHeight(20); // Set preferred height
        amountAddBillTextArea.setStyle("-fx-prompt-text-fill: #000000;"); // Set prompt text color to darker shade of gray
        amountAddBillTextArea.setPromptText(addBillAmountTextAreaDefault);

        // HBOX
        HBox amountAddBillBox = new HBox(10);
        amountAddBillBox.getChildren().addAll(amountAddBill, amountAddBillTextArea);
        //..........................................................
        //
        //
        //
        // Add Bill Type LABEL - DROPDOWN MENU - HBOX
        Label typeAddBill = new Label("Type: ");

        // Create the dropdown menu
        String[] options = {"Select Type", "Utility", "Entertainment", "Borrowed"};
        JComboBox<String> dropdown = new JComboBox<>(options);

        // Add an action listener to the dropdown menu
        dropdown.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JComboBox<String> combo = (JComboBox<String>) e.getSource();
                String selectedOption = (String) combo.getSelectedItem();
                System.out.println("Selected: " + selectedOption);
            }
        });

        // Create a SwingNode to embed the Swing components
        SwingNode swingNode = new SwingNode();
        swingNode.setContent(createSwingContent(dropdown));

        // Create an HBox for JavaFX
        HBox dropdownHBox = new HBox(10);
        dropdownHBox.getChildren().addAll(typeAddBill, swingNode);
        //..........................................................
        //
        //
        //
        // Add Bill Date
        // LABEL
        Label dueDateAddBillLabel = new Label("Due Date: ");

        // DATEPICKER
        DatePicker datePicker = new DatePicker();
        datePicker.setPromptText("Select a date ->"); // Set prompt text
        datePicker.setStyle("-fx-prompt-text-fill: black; -fx-text-fill: black;"); // Set prompt text color and text color        datePicker.setPromptText("Select a date >"); // Set prompt text

        // HBOX
        HBox dueDateAddBillBox = new HBox(10);
        dueDateAddBillBox.getChildren().addAll(dueDateAddBillLabel, datePicker);
        //..........................................................
        //
        //
        //
        // Add Bill Notes

        // LABEL
        Label notesAddBill = new Label("Notes: ");

        // TEXTAREA
        String notesAddBillTextAreaDefault = "Type descriptive expense details or payment instructions.";
        TextArea notesAddBillTextArea = new TextArea();
        notesAddBillTextArea.setPrefWidth(240); // Set preferred width
        notesAddBillTextArea.setPrefHeight(100); // Set preferred height
        notesAddBillTextArea.setPromptText(notesAddBillTextAreaDefault);
        notesAddBillTextArea.setStyle("-fx-prompt-text-fill: #000000;"); // Set prompt text color to darker shade of gray

        // HBOX
        HBox notesAddBillBox = new HBox(10);
        notesAddBillBox.getChildren().addAll(notesAddBill, notesAddBillTextArea);
        //..........................................................
        //
        //
        //
        // Add Bill BOX
        VBox addBillBox = new VBox(10);
        addBillBox.setStyle("-fx-border-color: black; -fx-border-width: 2px;"); // Set border style
        addBillBox.setPadding(new Insets(10)); // Add a larger padding to the VBox
        addBillBox.getChildren().addAll(labelAddBillBox, billNameAddBillBox, amountAddBillBox,
                dropdownHBox, dueDateAddBillBox, notesAddBillBox);
        addBillBox.setAlignment(Pos.CENTER);
        //</editor-fold>
//=====================================================================================================================
    // GUI FULL MENU BOX PLACEMENT ##########################################################################################
        //<editor-fold desc=">>> FOLD OF (GUI FULL MENU BOX PLACEMENT)">
        // Box of full menu boxes
        VBox menuBoxes = new VBox(10);
        menuBoxes.getChildren().addAll(welcomeLearnBox, textAreaMonthBoxes, addBillBox);
        menuBoxes.setAlignment(Pos.CENTER);
        //</editor-fold>
//=====================================================================================================================
    //Bookmarks(1123312)
    // BUTTON LISTENERS !!! POSSIBLE IMPLEMENTATION ##########################################################################################
        //<editor-fold desc="FOLD OF (BUTTON LISTENERS !!! POSSIBLE IMPLEMENTATION)">
        /*
        // Associate buttons to listener
        ButtonClickHandler eventManager = new ButtonClickHandler();
        submitAddBill.setOnAction( eventManager );
        sortNameAsc.setOnAction( eventManager );
        sortPointsDesc.setOnAction( eventManager );
        sortAgeAsc.setOnAction( eventManager );
        addPlayerButton.setOnAction( eventManager );
        deletePlayerButton.setOnAction( eventManager );
        randomizePlayerButton.setOnAction( eventManager );
        writeListToFile.setOnAction( eventManager );
*/
        //</editor-fold>
//=====================================================================================================================
    // UPDATE TEXTAREAS ##########################################################################################
        //<editor-fold desc=">>>FOLD OF (UPDATE TEXTAREAS)">
        // Assuming you've already created the TextArea
        textAreaThisMonth.setStyle("-fx-font-weight: bold;"); // Set the entire text bold
        textAreaThisMonth.setWrapText(true); // Enable text wrapping
        bill.readBillsFromFile();
        textAreaThisMonth.setText(bill.toString()); // Set the text content
        //</editor-fold>
//=====================================================================================================================
// GUI FOR BORDERPANE - SCENE - STAGE #############################################################################
        //<editor-fold desc=">>>FOLD OF (GUI FOR BORDERPANE - SCENE - STAGE)">
        // Create the border pane
        BorderPane mainGUIpane = new BorderPane();
        mainGUIpane.setTop(menuBar);
        mainGUIpane.setCenter(menuBoxes);
        //..........................................................
        //
        //
        //
        // Scene
        Scene scene = new Scene(mainGUIpane, 1500, 1000);
        //..........................................................
        //
        //
        //
        // Setting the Scene to the Stage
        primaryStage.setScene(scene);
        primaryStage.setTitle("Will.E.M - \"At your service!\" ");
        scene.getStylesheets().add("WillEMStyles.css");
        primaryStage.setX(0); // X coordinate - Set the location of the window
        primaryStage.setY(0); // Y coordinate - Set the location of the window
        primaryStage.show();
        //</editor-fold>
//=====================================================================================================================
    } // END OF - private void showMainMenu(Stage primaryStage)
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================

    // Button Response
    private void showLearnAboutMeDialog() {
        // Dialog to learn about Will.E.M
        JOptionPane.showMessageDialog(null,
                "\"Hello there! I'm Will.E.M, your trusty digital assistant for all things finance! \n" +
                "***************************************************************************************** \n" +
                "My name encompasses a multitude of meanings, each highlighting \n" +
                "my capabilities in managing your financial affairs. \n" +
                "***************************************************************************************** \n" +
                "                                           I am your 'Will Electronic Manager', diligently \n" +
                "                                               overseeing your financial transactions. \n" +
                "***************************************************************************************** \n" +
                "As a 'Will Expense Monitor', I keep a vigilant \n" +
                "eye on your spending habits to ensure financial wellness. \n" +
                "***************************************************************************************** \n" +
                "                                   With finesse, I am your 'Will Efficient Money-handler', \n" +
                "                                       adept at optimizing your financial resources. \n" +
                "***************************************************************************************** \n" +
                "Furthermore, I am your 'Will Earnings Master', \n" +
                "skilled in maximizing your income potential. \n" +
                "***************************************************************************************** \n" +
                "               However, above all, I am your 'Will Electronic Mate'! \n" +
                "                   Here to support and assist you in navigating \n" +
                "                    the complexities of your financial journey!");
    }
//=====================================================================================================================
    // Button Response
    private void addBillToList(){
        //Add info in textField/Area to a new bill instance
    }
//=====================================================================================================================
    // This method prompts the user to answer yes or no to confirm the action they chose
    public static boolean showConfirmationDialog(String message) {
    int choice = JOptionPane.showConfirmDialog(null, message, "Confirmation", JOptionPane.YES_NO_OPTION);
    if (choice == JOptionPane.YES_OPTION) {
        return true; // Proceed with the action
    } else if (choice == JOptionPane.NO_OPTION) {
        return false; // Cancel the action
    } else {
        JOptionPane.showMessageDialog(null, "Action canceled."); // Inform the user that the action has been canceled
        return false; // Cancel the action
    }
}
//=====================================================================================================================
    // Define other methods for managing savings, budgets, stats, purchases, and security
    private JPanel createSwingContent(JComboBox<String> dropdown) {
        JPanel panel = new JPanel();
        panel.add(dropdown);
        return panel;
    }
//=====================================================================================================================
    //Private class to possibly implement a new button handler Bookmarks(34345345)
    /*
    // -------------------------------------------------------------
    // Private inner class for event handling
    class ButtonClickHandler implements EventHandler<javafx.event.ActionEvent> {
        @Override
        public void handle(javafx.event.ActionEvent event) {
            // If user clicks button, grab text currently stored
            // in text field and display it in a dialog
            if (event.getSource() == submitAddBill)
                if (showConfirmationDialog("Are you sure you want to add a One-Time Expense?")) {
                    OneTimeBill.submitAddBill();
                }
                //else if (event.getSource() == sortNameAsc)
                //playerDatabase.sortNameAsc();

                else {
                    // Do nothing and return to the GUI
                }

            // Write updated data to the text area
            //dataArea.setText(playerDatabase.toString());
        }
    }
*/
//=====================================================================================================================

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
} // End of Main class
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Bookmarks(1123312 + 34345345)I have commented out possible use of eventmanagers from TennisDB.java for use as button managers as opposed to
// the system I have now which is individual button managers at the sight of the buttons creation. There is commented
// code in the methods section, and just above the primary stage for the main menu gui