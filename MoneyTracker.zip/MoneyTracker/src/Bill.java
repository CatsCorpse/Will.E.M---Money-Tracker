import java.io.File;
import java.io.IOException;
import java.util.Scanner;

class Bill {

    public String name;
    public double amount;
    public int date;
    public int month;
    public String type;
    public String priority;
    public String payPlace;
    public String credentials;
    public String notes;

    // Number of actual data elements stored in array
    private int numElems;


    final int MAX_ARRAY_SIZE = 100;

    // Data storage arrays - related info stored in parallel

    final String[] nameArray = new String[MAX_ARRAY_SIZE];
    final double[] amountArray = new double[MAX_ARRAY_SIZE];
    final int[] dateArray = new int[MAX_ARRAY_SIZE];
    final int[] monthArray = new int[MAX_ARRAY_SIZE];
    final String[] typeArray = new String[MAX_ARRAY_SIZE];
    final String[] priorityArray = new String[MAX_ARRAY_SIZE];
    final String[] payPlaceArray = new String[MAX_ARRAY_SIZE];
    final String[] credentialsArray = new String[MAX_ARRAY_SIZE];
    final String[] notesArray = new String[MAX_ARRAY_SIZE];

    //----------------------------------------------------
    // Implement constructor, getters, and setters

    // No-Arg Constructor
    public Bill()
    {
        name = " ";
        amount = 0.0;
        date = 0;
        month = 0;
        type = " ";
        priority = " ";
        payPlace = " ";
        credentials = " ";
        notes = " ";

    }

    // Parameterized Constructor
    public Bill(String name, double amount, int date, int month, String type, String priority,
                String payPlace, String credentials, String notes)
    {
        this.name = name;
        this.amount = amount;
        this.date = date;
        this.month = month;
        this.type = type;
        this.priority = priority;
        this.payPlace = payPlace;
        this.credentials = credentials;
        this.notes = notes;
    }

    //SETTERS-------------------------------------
    public void setName (String name)
    {this.name = name;}

    public void setAmount (double amount)
    {this.amount = amount;}

    public void setDate (int date)
    {this.date = date;}

    public void setMonth (int month)
    {this.month = month;}

    public void setType (String type)
    {this.type = type;}

    public void setPriority (String priority)
    {this.priority = priority;}

    public void setPayPlace (String payPlace)
    {this.payPlace = payPlace;}

    public void setCredentials (String credentials)
    {this.credentials = credentials;}

    public void setNotes (String notes)
    {this.notes = notes;}

    //GETTERS-------------------------------------
    public String getName ()
    {return name;}

    public double getAmount ()
    {return amount;}

    public int getDate ()
    {return date;}

    public int getMonth ()
    {return month;}

    public String getType ()
    {return type;}

    public String getPriority ()
    {return priority;}

    public String getPayPlace ()
    {return payPlace;}

    public String getCredentials ()
    {return credentials;}

    public String getNotes ()
    {return notes;}

    // METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------

    public void readBillsFromFile() {
        // Load arrays from file
        try {

            String dataLine;
            Scanner inputFileScanner;
            File inputfile;
            String INPUT_FILENAME = "testBills.txt";
            inputfile = new File(INPUT_FILENAME);
            inputFileScanner = new Scanner(inputfile);

            // Loop through file.  Tokenize each line into correct array.
            int i = 0;
            while (inputFileScanner.hasNext()) {
                // Read one line and instantiate a tokenizer object
                // Read the entire line
                dataLine = inputFileScanner.nextLine();

                // Split the line based on commas
                String[] tokens = dataLine.split(",");

                // Tokenize line and save data
                nameArray[i] = tokens[0].trim(); // Trim to remove leading/trailing spaces
                amountArray[i] = Double.parseDouble(tokens[1].trim());
                dateArray[i] = Integer.parseInt(tokens[2].trim());
                monthArray[i] = Integer.parseInt(tokens[3].trim());
                typeArray[i] = tokens[4].trim();
                priorityArray[i] = tokens[5].trim();
                payPlaceArray[i] = tokens[6].trim();
                credentialsArray[i] = tokens[7].trim();
                notesArray[i] = tokens[8].trim();

                System.out.println(getBillFormattedByIndex(i));

                // Advance index
                i++;
            }
            numElems = i;

            inputFileScanner.close();   // Close file
        } catch (IOException e)  // If file error, send note to log and shut down.
        {
            System.out.println("File Input Error");
            System.exit(0);
        }
    }

// METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------

    // This method returns one set of player data with formatting
    public String getBillFormatted() {

        return "Name: " + name + " = $"  + String.format("%.2f", amount) + " (" + type + ")" + "\n" +
                "Date/Month: " + date + "/" + month + "\n" +
                "Priority: " + priority + "\n" +
                "Pay Place: " + payPlace + "\n" + "Credentials: " + credentials + "\n" +
                "Notes: " + notes + "\n";
    }

// METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------

// This method returns one set of player data with formatting
public String getBillFormattedByIndex(int index) {

    return "Name: " + nameArray[index] + " = $"  + String.format("%.2f", amountArray[index]) +
            " (" + typeArray[index] + ")" + "\n" +
            "Date/Month: " + dateArray[index] + "/" + monthArray[index] + "\n" +
            "Priority: " + priorityArray[index] + "\n" +
            "Pay Place: " + payPlaceArray[index] + "\n" + "Credentials: " + credentialsArray[index] + "\n" +
            "Notes: " + notesArray[index] + "\n";
}

// METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------

    // This method returns all data elements for a player as a multi-line string formatted for output.
    public String toString() {
        StringBuilder outString = new StringBuilder();

        // Iterate through all bill data
        for (int i = 0; i < numElems; i++) {
            // Append the formatted data to the StringBuilder
            outString.append(getBillFormattedByIndex(i)).append("\n");
        }

        return outString.toString();
    }

// METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------

    public int getNumElems()
    {
        return numElems;
    }

// METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------

    public double getTotalTotal()
    {
        double totalTotal = 0.0;

        // Iterate through all bill data
        for (int i = 0; i < numElems; i++) {

            totalTotal += amountArray[i];
        }

        return totalTotal;
    }
// METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------METHOD BREAK---------

}// END OF CLASS