class Bill {
    private String name;
    private String dueMonth;
    private double amount;
    private String notes;
    private String type;
    private String colorPriority;
    private String paymentInstructions;








    // Implement constructor, getters, and setters
}