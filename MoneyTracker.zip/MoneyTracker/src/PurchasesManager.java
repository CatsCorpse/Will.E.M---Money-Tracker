public class PurchasesManager {
}
