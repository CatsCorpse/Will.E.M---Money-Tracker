public class StatsManager {
}
