class BudgetManager {
    private double yearlyBudget;
    private double monthlyBudget;
    private double weeklyBudget;
    private double dailyBudget;

    // Implement methods for managing budgets
}